from exnovaapi.http.resource import Resource


class Register(Resource):

    url = "register"
