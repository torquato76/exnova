from exnovaapi.http.resource import Resource


class Auth(Resource):
    url = "auth"
