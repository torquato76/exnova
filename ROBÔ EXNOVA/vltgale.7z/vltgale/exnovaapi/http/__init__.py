"""Module for  API http resources."""
