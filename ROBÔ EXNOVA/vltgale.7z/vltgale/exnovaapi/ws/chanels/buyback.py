from exnovaapi.ws.chanels.base import Base


class Buyback(Base):

    name = "buyback"

    def __call__(self):

        pass
